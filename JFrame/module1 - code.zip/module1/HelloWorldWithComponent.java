package module1;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class HelloWorldWithComponent {
  public static void main(String[] args) {
    JFrame frame = new JFrame("Hello, world");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    JLabel label = new JLabel("Hello, world - with component!");
    frame.add(label);
    frame.setLocationRelativeTo(null); // center on screen
    frame.pack();
    frame.setVisible(true);
  }
}
