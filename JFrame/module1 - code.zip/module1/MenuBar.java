package module1;

import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

public class MenuBar {
  public static void main(String[] args) {
    JFrame frame = new JFrame("Menu bar");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    // Menu:
    JMenuBar menuBar = new JMenuBar();
    JMenu menuFile = new JMenu("File");
    JMenuItem menuItemNew = new JMenuItem("New");
    JMenuItem menuItemSaveAs = new JMenuItem("Save As ...");
    JMenuItem menuItemExit = new JMenuItem("Exit");
    menuFile.add(menuItemNew);
    menuFile.add(menuItemSaveAs);
    menuFile.add(menuItemExit);
    menuBar.add(menuFile); // adds menu bar to the frame
    frame.setJMenuBar(menuBar);

    frame.setSize(300, 200);
    frame.setLocationRelativeTo(null);
    frame.setVisible(true);
  }
}
