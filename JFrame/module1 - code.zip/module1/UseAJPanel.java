package module1;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.FlowLayout;
import javax.swing.JPanel;

public class UseAJPanel {
  public static void main(String[] args) {
    JFrame frame = new JFrame("Use a JPanel");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    JPanel panel = new JPanel();
    // panel.setLayout(new FlowLayout());
    frame.add(panel);
    JLabel label = new JLabel("Hello, world - with component!");
    JLabel label2 = new JLabel("Label 2");
    panel.add(label);
    panel.add(label2);
    frame.setLocationRelativeTo(null); // center on screen
    frame.pack();
    frame.setVisible(true);
  }
}
