package module1;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.FlowLayout;

public class UseAFlowLayoutManager {
  public static void main(String[] args) {
    JFrame frame = new JFrame("Use a FlowLayoutManager");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setLayout(new FlowLayout());
    JLabel label = new JLabel("Hello, world - with component!");
    JLabel label2 = new JLabel("Label 2");
    frame.add(label);
    frame.add(label2);
    frame.setLocationRelativeTo(null); // center on screen
    frame.pack();
    frame.setVisible(true);
  }
}