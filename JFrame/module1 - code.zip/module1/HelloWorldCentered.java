package module1;

import javax.swing.JFrame;

public class HelloWorldCentered {
    public static void main(String[] args) {
      JFrame frame = new JFrame("Hello, world");
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setLocationRelativeTo(null); // Center frame on screen
      frame.setVisible(true);
    }
}
