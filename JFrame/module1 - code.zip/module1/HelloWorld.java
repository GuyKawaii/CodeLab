package module1;

import javax.swing.JFrame;

public class HelloWorld {
  void run() {
    JFrame frame = new JFrame("Hello, world");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setVisible(true);
  }

  public static void main(String[] args) {
    new HelloWorld().run();
  }
}
