package module1;

import javax.swing.JFrame;
import javax.swing.JLabel;

class HelloWorldThreadSafe {
  void run() {
    JFrame frame = new JFrame("module1.HelloWorldThreadSafe");
    frame.add(new JLabel("module1.HelloWorldThreadSafe"));
    frame.setLocationRelativeTo(null);
    frame.pack();
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setVisible(true);
  }

  public static void main(String[] args) {
    javax.swing.SwingUtilities.invokeLater(new Runnable() { public void run() { new HelloWorldThreadSafe().run(); } });
  }
}
/*
  On invokeLater: Swing is a single-threaded GUI toolkit.
  There is a special thread called the Event Dispatch Thread (EDT)
  that is dedicated to displaying and updating Swing components.
  invokeLater() is a helper method to ensure that any code
  that modifies the GUI in some way only ever does so while running on this special EDT.
  The invokeLater method will call the code in the "run" method at some point in the future
  on the Event Dispatch Thread.
  I would presume that the createAndShowGUI method will create,
  initialise and display components, hence it must only be run on the EDT.
 */
